
import java.util.*;

public class App {

    /**
     * Default constructor
     */
    public App() {
    }

    /**
     * @param argv 
     * @return
     */
    public static void main(String[] args) {
        // TODO implement here
        System.out.println("Programa 1a");
	Logic log1a = new Logic();
	log1a.logic1a();
        
        
    }

}